_result=`b2 ls --json apksite | grep -B 4 us.ollies.app.apk | grep "fileId"`


_fileID=`echo $_result | grep -oP '(?<="fileId": ")[^"]*'`

b2 get-file-info $_fileID
