#sh
_dbase='apkfile_clone'
_dpass='eCkboB6P3yLrcJkeLjPYZeOxRkAqfRh4DomD4mCxPFUyGsXGDWwqf'

for file in download/*.apk; do
	_m5=`md5sum ${file} | awk '{ print $1 }'`
	filename=`basename $file`
	filename="${filename%.*}"
	echo $filename "|" $_m5 >runme.out
#update apkdetails set md5 = $_m5 where appID = '$filename'
mysql --host=localhost --user=$_dbase --password=$_dpass $_dbase -e "use $_dbase ;update apkdetails set md5 = '$_m5' where appId = '$filename'"

done

